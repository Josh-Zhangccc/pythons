def add(a, b):
    return a + b

if __name__ == '__main__':
    print(add(10, 20))  # 只有当运行calc2时候才能运行这句话

