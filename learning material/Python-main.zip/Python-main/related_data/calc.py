def add(a, b):
    return a + b


def div(a, b):
    return a / b


# 如何去导入自定义模块
